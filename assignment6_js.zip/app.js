//Positive integer – round, floor, ceil
var num = parseFloat(prompt("Enter a positive number:"));

document.write("Number: " + num + "<br>");
document.write("Round off value: " + Math.round(num) + "<br>");
document.write("Floor value: " + Math.floor(num) + "<br>");
document.write("Ceil value: " + Math.ceil(num));

//Negative floating-point number
var num = parseFloat(prompt("Enter a negative number:"));

document.write("Number: " + num + "<br>");
document.write("Round off value: " + Math.round(num) + "<br>");
document.write("Floor value: " + Math.floor(num) + "<br>");
document.write("Ceil value: " + Math.ceil(num));

//Absolute value
var num = parseFloat(prompt("Enter a number:"));
document.write("Absolute value: " + Math.abs(num));

//Dice using random()
var dice = Math.floor(Math.random() * 6) + 1;
document.write("Dice value: " + dice);

//Coin toss
var toss = Math.floor(Math.random() * 2) + 1;

if (toss === 1) {
  document.write("Coin Value: Heads");
} else {
  document.write("Coin Value: Tails");
}

//Random number between 1 and 100
var randomNum = Math.floor(Math.random() * 100) + 1;
document.write("Random number between 1 and 100: " + randomNum);

//Parse user weight
var weightInput = prompt("Enter your weight:");
var weight = parseFloat(weightInput);

document.write("Your weight is " + weight + " kg");

//Secret number game (1–10)
var secretNum = Math.floor(Math.random() * 10) + 1;
var userNum = parseInt(prompt("Guess the secret number (1 to 10):"));

if (userNum === secretNum) {
  document.write(" Congratulations! You guessed the correct number.");
} else {
  document.write("Sorry! The secret number was " + secretNum);
}