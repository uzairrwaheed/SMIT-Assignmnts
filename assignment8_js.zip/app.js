//Display current date and time
var now = new Date();
document.write(now);

//Alert current month in words
var months = ["January","February","March","April","May","June","July","August","September","October","November","December"];
var now = new Date();
alert(months[now.getMonth()]);

//Alert first 3 letters of current day
var days = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
var now = new Date();
alert(days[now.getDay()]);

//Show “It’s Fun day” if Saturday or Sunday
var now = new Date();
var day = now.getDay();

if (day === 0 || day === 6) {
  alert("It’s Fun day");
}

//First fifteen days or last days of month
var date = new Date().getDate();

if (date < 16) {
  alert("First fifteen days of the month");
} else {
  alert("Last days of the month");
}

//Minutes since Jan 1, 1970
var d = new Date();
var minutes = d.getTime() / (1000 * 60);
document.write("Minutes since Jan 1, 1970: " + minutes);

//Check AM or PM
var hours = new Date().getHours();

if (hours < 12) {
  alert("Its AM");
} else {
  alert("Its PM");
}

//Last day of last month of 2020
var laterDate = new Date(2020, 11, 31);
document.write(laterDate);

//Days passed since 1st Ramadan (June 18, 2015)
var ramadan = new Date("June 18, 2015");
var today = new Date();
var diff = today - ramadan;
var daysPassed = Math.floor(diff / (1000 * 60 * 60 * 24));

alert(daysPassed + " days have passed since 1st Ramadan, 2015");

//Seconds elapsed between reference date and beginning of 2015
var refDate = new Date();
var start2015 = new Date("January 1, 2015");
var seconds = Math.floor((refDate - start2015) / 1000);

document.write("Seconds elapsed since Jan 1, 2015: " + seconds);

//Add one hour to current time
var now = new Date();
document.write("Current date: " + now + "<br>");

now.setHours(now.getHours() + 1);
document.write("1 hour ahead: " + now);

//Date reset to 100 years back
var date = new Date();
date.setFullYear(date.getFullYear() - 100);

alert(date);

//Ask age and calculate birth year
var age = prompt("Enter your age:");
var currentYear = new Date().getFullYear();
var birthYear = currentYear - age;

document.write("Your birth year is: " + birthYear);

//K-Electric Bill
var customerName = "Uzair Waheed";
var month = new Date().toLocaleString('default', { month: 'long' });
var units = 410;
var chargesPerUnit = 16;
var lateSurcharge = 350;

var netAmount = units * chargesPerUnit;
var grossAmount = netAmount + lateSurcharge;

document.write("<h2>K-Electric Bill</h2>");
document.write("Customer Name: " + customerName + "<br>");
document.write("Month: " + month + "<br>");
document.write("Number of Units: " + units + "<br>");
document.write("Charges per Unit: " + chargesPerUnit.toFixed(2) + "<br>");
document.write("Net Amount Payable (within Due Date): " + netAmount.toFixed(2) + "<br>");
document.write("Late Payment Surcharge: " + lateSurcharge.toFixed(2) + "<br>");
document.write("Gross Amount Payable (after Due Date): " + grossAmount.toFixed(2));