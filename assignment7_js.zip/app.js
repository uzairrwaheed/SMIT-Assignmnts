//Merge first & last name and greet
var firstName = prompt("Enter your first name:");
var lastName = prompt("Enter your last name:");
var fullName = firstName + " " + lastName;
document.write("Hello " + fullName);

//Length of favorite mobile model
var mobile = prompt("Enter your favorite mobile phone model:");
document.write("Length of string: " + mobile.length);

//Index of letter “n” in “Pakistani”
var word = "Pakistani";
document.write("Index of n: " + word.indexOf("n"));

//Last index of “l” in “Hello World”
var text = "Hello World";
document.write("Last index of l: " + text.lastIndexOf("l"));

//Character at 3rd index in “Pakistani”
var word = "Pakistani";
document.write("Character at index 3: " + word.charAt(3));

//Q1 using concat()
var firstName = prompt("Enter first name:");
var lastName = prompt("Enter last name:");
var fullName = firstName.concat(" ", lastName);
document.write("Hello " + fullName);

//Replace “Hyder” with “Islam”
var city = "Hyderabad";
var newCity = city.replace("Hyder", "Islam");
document.write(newCity);

//Replace all “and” with “&”
var message = "Ali and Sami are best friends. They play cricket and football together.";
var result = message.replace(/and/g, "&");
document.write(result);

//Convert string “472” to number
var str = "472";
var num = Number(str);

document.write("Value: " + str + "<br>");
document.write("Type: " + typeof str + "<br><br>");
document.write("Value: " + num + "<br>");
document.write("Type: " + typeof num);

//Convert input to capital letters
var input = prompt("Enter any text:");
document.write(input.toUpperCase());

//Convert input to Title Case
var input = prompt("Enter any text:");
var titleCase = input.toLowerCase().split(" ");

for (var i = 0; i < titleCase.length; i++) {
  titleCase[i] = titleCase[i][0].toUpperCase() + titleCase[i].slice(1);
}

document.write(titleCase.join(" "));

//Remove dot from number
var num = 35.36;
var result = num.toString().replace(".", "");
document.write(result);

//Username validation
var username = prompt("Enter username:");
var isValid = true;

for (var i = 0; i < username.length; i++) {
  var code = username.charCodeAt(i);
  if (code === 33 || code === 44 || code === 46 || code === 64) {
    isValid = false;
    break;
  }
}

if (isValid) {
  document.write("Valid username");
} else {
  alert("Please enter a valid username");
}

//Search item in array (case-insensitive)
var items = ["cake", "apple pie", "cookie", "chips", "patties"];
var search = prompt("Enter item to search:").toLowerCase();

if (items.includes(search)) {
  document.write(search + " is available");
} else {
  document.write(search + " is not available");
}

//Password validation
var password = prompt("Enter password:");

var hasAlpha = false;
var hasNum = false;

if (password.length >= 6 && isNaN(password[0])) {
  for (var i = 0; i < password.length; i++) {
    var code = password.charCodeAt(i);
    if ((code >= 65 && code <= 90) || (code >= 97 && code <= 122)) {
      hasAlpha = true;
    }
    if (code >= 48 && code <= 57) {
      hasNum = true;
    }
  }

  if (hasAlpha && hasNum) {
    document.write("Valid password");
  } else {
    alert("Invalid password");
  }
} else {
  alert("Invalid password");
}

//Convert string to array
var university = "University of Karachi";
var arr = university.split("");

for (var i = 0; i < arr.length; i++) {
  document.write(arr[i] + "<br>");
}

//Display last character of input
var input = prompt("Enter any text:");
document.write("Last character: " + input.charAt(input.length - 1));

//Count occurrences of “the”
var str = "The quick brown fox jumps over the lazy dog";
var count = str.toLowerCase().match(/the/g).length;
document.write("Occurrences of 'the': " + count);